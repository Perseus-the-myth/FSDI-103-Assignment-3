//Define the Function

function sayHello(userName=`User` ){
    console.log("Hello " + userName+" ! ");
}

function max(number1, number2){
    if(number1>number2){
        console.log(number1);
        console.log(`Example`);
    }
    else{
        console.log(number2);
    }
}
max(5,9); 
max(10,12);
max(16,20);